"use strict";
exports.__esModule = true;
var stream_1 = require("stream");
var mod = [
    { requires: "names", contentType: "application/x-ndjson" },
    function (input) {
        var out = new stream_1.PassThrough({ objectMode: true });
        this.logger.trace("Instance started");
        input
            .map(function (data) { return "Hello ".concat(data.name, "! \n"); })
            .pipe(out);
        return out;
    }
];
exports["default"] = mod;
